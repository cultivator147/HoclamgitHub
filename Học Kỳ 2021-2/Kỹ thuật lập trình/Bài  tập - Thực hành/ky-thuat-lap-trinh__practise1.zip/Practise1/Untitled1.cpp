#include<iostream>
using namespace std;

void input(int **matrix, int n){
    int a;
    for (int i=0;i<n;i++)
        for(int j=0;j<n;j++){
            cin>>a;
            matrix[i][j] = a;
        }
        cout<<endl;
}
void output(int **matrix, int n){
    for (int i=0;i<n;i++){
        for(int j=0;j<n;j++)
        cout<<matrix[i][j]<<" ";
        cout<<endl;
}       cout<<endl;
}
void free_mt(int **matrix, int n){
    for(int i=0;i<n;i++) delete[] matrix[i];
    delete[]matrix;
}

int** sum(int **matrix_1, int **matrix_2, int n){
	int **matrix= new int *[n];
	for(int i=0;i<n;i++){
		matrix[i]= new int[n];
	}
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++)
		{
			matrix[i][j]= matrix_1[i][j]+ matrix_2[i][j];
		}
	}
	return matrix;
}
int** multiply (int **matrix_1, int **matrix_2,int n){
	int **matrix= new int *[n];
	for(int i=0;i<n;i++){
		matrix[i]= new int[n];
	}
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			int sum=0;
			for(int k=0;k<n;k++){
				sum+= matrix_1[i][k] * matrix_2[k][j];
			}
			matrix[i][j]= sum;
		}
	}
	return matrix;
}
int main(){
    int n, **matrix_1, **matrix_2;
    cin>>n;
    matrix_1 = new int*[n];
    for (int i=0; i<n ;i++)
        matrix_1[i] = new int[n];

    matrix_2 = new int*[n];
    for (int i=0; i<n ;i++)
        matrix_2[i] = new int[n];

    input(matrix_1,n);
    input(matrix_2,n);

    int **matrix_3;
    matrix_3= new int*[n];
	for(int i=0;i<n;i++){
		matrix_3[i]= new int [n];
	}
	matrix_3 = sum(matrix_1, matrix_2, n);
    output(matrix_3,n);

    int **matrix_4;
    matrix_4 = new int*[n];
	for(int i=0;i<n;i++){
		matrix_4[i]= new int [n];
	}
    matrix_4 = multiply(matrix_1,matrix_2,n);
    output(matrix_4,n);

    free_mt(matrix_1,n);
    free_mt(matrix_2,n);
    free_mt(matrix_3,n);
    free_mt(matrix_4,n);
    return 0;
}
