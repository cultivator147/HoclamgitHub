#include<iostream>
using namespace std;
#define MAXN 30

/*void reversearray(int arr[], int size){
     int i, j, tmp;
     i=0;
     j= size -1;
     for (i = 0; i<size/2;i++)
     {
         tmp = arr[i];
         arr[i] = arr[j];
         arr[j] = tmp;
         j--;
     }
}
/*****************
# YOUR CODE HERE #
*****************/

void reversearray(int *arr, int size){
    int i, j, tmp;
    j= size -1;
    for (i = 0; i<size/2;i++)
    {
        tmp = *(arr+i);
        *(arr+i) = *(arr+j);
        *(arr+j) = tmp;
        j--;
    }
}
/*****************
# YOUR CODE HERE #
*****************/

int main()
{
    int a[7] = {1,2,5,7,9,4,6};
    reversearray(a,7);
    for (int i = 0; i<7;i++) cout<<*(a+i)<<"\t";
}
