#include<iostream>
using namespace std;
int **mt3;
void input(int **mt, int n){
    for (int i=0;i<n;i++)
        for(int j=0;j<n;j++){
            cout<< "["<<i<<","<<j<<"] = ";
            cin>>*(*(mt+i)+j);
        }
}
void output(int **mt, int n){
    for (int i=0;i<n;i++){
        for(int j=0;j<n;j++)
        cout<<*(*(mt+i)+j)<<"\t";
        cout<<endl;
}
}
/*void allocate(int **mt, int n){
    mt = new int*[n];
    for (int i=0; i<n ;i++)
        mt[i] = new int[n];
}*/
void free_mem(int **mt, int n){
    for(int i=0;i<n;i++) delete[] (mt+i);
    delete[]mt;
}
void sum(int **mt1, int **mt2, int m){
    for (int i=0;i<m;i++) {
        for(int j=0;j<m;j++)
            *(*(mt3+i)+j) = *(*(mt1+i)+j) + *(*(mt2+i)+j) ;
    }
}
void multiply(int **mt1, int **mt2, int m){
    for (int i=0;i<m;i++){
        for(int j=0;j<m;j++){
            *(*(mt3+i)+j) = 0;

            for(int k=0;k<m;k++)
                *(*(mt3+i)+j)+= (*(*(mt1+i)+k) * *(*(mt2+k)+j) );
        }
    }
}
int main(){
    int n, **mt1, **mt2;
    cout<<"Enter n: "; cin>>n;
   // allocate(mt1,n);
    mt1 = new int*[n];
    for (int i=0; i<n ;i++)
        mt1[i] = new int[n];

    cout<<"Enter Matrix 1"; input(mt1,n);
    //allocate(mt2,n);
     mt2 = new int*[n];
    for (int i=0; i<n ;i++)
        mt2[i] = new int[n];

    cout<<"Enter Matrix 2"; input(mt2,n);
    //allocate(mt3,n);
	 mt3 = new int*[n];
    for (int i=0; i<n ;i++)
        mt3[i] = new int[n];

    sum(mt1,mt2,n);
    cout<<"Sum: ";
    output(mt3,n);

    multiply(mt1,mt2,n);
    cout<<"Multiply: ";
    output(mt3,n);

    free_mem(mt1,n);
    free_mem(mt2,n);
    free_mem(mt3,n);

}
