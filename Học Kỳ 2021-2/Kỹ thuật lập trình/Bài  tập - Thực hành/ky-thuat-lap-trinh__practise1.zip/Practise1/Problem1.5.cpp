#include<iostream>
using namespace std;
#define MAXN 30

 double* maximum(double* a, int size){
     double *max;
     double *p;
     int i;
     max=a; p=a;
     if (a==NULL) return NULL;
     else{ for(int i = 0; i<size; i++)
           if(*(a+i)>*max) max = a + i;
     }
     /*****************
     # YOUR CODE HERE #
     *****************/
     return max;
}

int main (){
    double a[7] = {1.23,-2.4,-5.44,7.8,9.0,4.6,8.0};
    cout<<"max ="<<maximum(a,7)<<"\t";
    cout<<"a[max] ="<<*maximum(a,7)<<endl;
    for(int i = 0; i<7; i++)
        cout<<*(a+i)<<"\t";
    return 0;
}


