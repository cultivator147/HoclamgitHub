#include<iostream>
using namespace std;
#define MAXN 30
int counteven(int* arr, int size){
     int i;
     int count =0;
     for (i=0; i<size; i++)
        if(!(*(arr+i)%2)) count++;
        /*****************
        # YOUR CODE HERE #
        *****************/
     return count;
}

int main()
{
    int a[7] = {1,2,5,7,9,4,6};
    int value = counteven(a,7);
    cout<<value;
    return 0;
}

