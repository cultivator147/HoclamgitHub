#include <iostream>
#include <ostream>
#include <math.h>
using namespace std;
struct Complex {
double real;
double imag;
};
Complex operator + (Complex a, Complex b) {
    Complex tmp;
    tmp.real = a.real + b.real;
    tmp.imag = a.imag + b.imag;
    return tmp;
/*****************
# YOUR CODE HERE #
*****************/
}
Complex operator - (Complex a, Complex b) {
    Complex tmp;
    tmp.real = a.real - b.real;
    tmp.imag = a.imag - b.imag;
    return tmp;
/*****************
# YOUR CODE HERE #
*****************/
}
Complex operator * (Complex a, Complex b) {
    Complex tmp;
    tmp.real = a.real*b.real - a.imag*b.imag;
    tmp.imag = a.real*b.imag + a.imag*b.real;
    return tmp;
/*****************
# YOUR CODE HERE #
*****************/
}
Complex operator / (Complex a, Complex b) {
    Complex tmp;
    tmp.real = (a.real*b.real + a.imag*b.imag)/(b.real*b.real - b.imag*b.imag) ;
    tmp.imag = (a.imag*b.real - a.real*b.imag)/(b.real*b.real - b.imag*b.imag) ;
    return tmp;
/*****************
# YOUR CODE HERE #
*****************/
}
ostream& operator << (ostream& out, const Complex &a) {
    out << '(' << a.real << (a.imag >= 0 ? '+' : '-') << fabs(a.imag) << 'i' << ')';
    return out;
}
int main() {
    Complex a{-6, -3};
    Complex b{4, 6};
    cout << a << " + " << b << " = " << a + b << endl;
    cout << a << " - " << b << " = " << a - b << endl;
    cout << a << " * " << b << " = " << a * b << endl;
    cout << a << " / " << b << " = " << a / b << endl;
    return 0;
}
