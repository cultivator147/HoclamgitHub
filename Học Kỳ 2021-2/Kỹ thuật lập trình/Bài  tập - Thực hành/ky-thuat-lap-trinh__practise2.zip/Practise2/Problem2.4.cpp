#include <iostream>
using namespace std;
int cube(int x) {
// trả về lập phương của x
    return x*x*x;
/*****************
# YOUR CODE HERE #
*****************/
}
// viết hàm tính lập phương của một số kiểu double
double cube(double x){
    return x*x*x;
}
/*****************
# YOUR CODE HERE #
*****************/
int main() {
    int n = 17;
    cout << "Int: " << cube(n) << endl;
    cout << "Double: " << cube(17.1) << endl;
    return 0;
}
