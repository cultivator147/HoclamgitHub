#include <stdio.h>
void rotate(int &x, int &y, int &z) {
    x = x + y + z;
	z = x - y - z;
	y = x - y - z;
	x = x - y - z;
/*****************
# YOUR CODE HERE #
*****************/
}
int main() {
    int x = 3;
    int y = 4;
    int z = 5;
// gán x bằng chữ số hàng đơn vị của mã số sinh viên
    x = 0;
// gán y bằng chữ số hàng chục của mã số sinh viên
    y = 3;
// gán z bằng chữ số hàng trăm của mã số sinh viên
    z = 7;
/*****************
# YOUR CODE HERE #
*****************/
    printf("Before: %d, %d, %d\n", x, y, z);
    rotate(x, y, z);
    printf("After: %d, %d, %d\n", x, y, z);
    return 0;
}
