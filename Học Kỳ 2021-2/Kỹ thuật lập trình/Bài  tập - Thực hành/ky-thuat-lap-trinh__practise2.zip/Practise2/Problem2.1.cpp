#include <stdio.h>
#include <math.h>
float get_hypotenuse(float x, float y) {
    return sqrt(x*x + y*y);
/*****************
# YOUR CODE HERE #
*****************/
}
int main(){
    float x = 3;
    float y = 4;
// gán x bằng 4 chữ số đầu của mã số sinh viên
// gán y bằng 4 chứ số cuối của mã số sinh viên
    x = 2018;
    y = 3730;
/*****************
# YOUR CODE HERE #
*****************/
    float z = get_hypotenuse(x, y);
    printf("z = %.2f\n", z);
    return 0;
}
