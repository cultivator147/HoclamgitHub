#include<bits/stdc++.h>
using namespace std;

int main()
{
	stack <int> s;
	int m = 1024;
	while (m > 0) {
        s.push(m % 2);
        m /= 2;
	}
	while(!s.empty()){
        cout<<s.top();
        s.pop();
	}
	return 0;
}
