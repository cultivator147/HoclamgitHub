#include <iostream>
#include <cstring>
using namespace std;
// viết hàm multiply, nhận vào 2 mảng mảng biểu diễn đa thức và độ dài của chúng
// trả về con trỏ tới mảng kết quả
template <typename T>
T arr_sum(T *a, int m, T *b, int n){
    T s = 0;
    for (int i = 0; i < m; i++) s += a[i];
    for (int i = 0; i < n; i++) s += b[i];
    return s;
}
/*****************
# YOUR CODE HERE #
*****************/
int main() {
{
    int a[] = {3, 2, 0, 5};
    int b[] = {5, 6, 1, 2, 7};
    cout<< arr_sum(a,4,b,5)<<endl;
    //int *c = multiply(a, 4, b, 5);
    //for (int i = 0; i < 8; ++i) printf("%d ", c[i]);
    //printf("\n");
}
{
    double a[] = {3.0, 2, 0, 5};
    double b[] = {5, 6.1, 1, 2.3, 7};
    cout<< arr_sum(a,4,b,5)<<endl;
    //double *c = multiply(a, 4, b, 5);
    //for (int i = 0; i < 8; ++i) printf("%.2f ", c[i]);
    //printf("\n");
}
    return 0;
}
