#include <stdio.h>

int lucas(int n) {
    if(n > 1) return lucas(n - 1) + lucas(n - 2);
    if(n == 1) return 1;
    return 2;
}

int main(){
    for (int n = 0; n <= 10; ++n)
        printf("L[%d] = %d\n", n, lucas(n));
    return 0;
}
