#include <bits/stdc++.h>
using namespace std;
/* Concursive
int M,n;
int m[100], x[100], sum = 0;

void TRY(int i){
    if (sum == M) {
        for (int i = 1;  i<= n; ++i) {
            if(x[i] == -1) cout << '-' << m[i];
            if(x[i] == 1) cout << '+' << m[i];
        }
        cout << " = " << M <<endl;
    }
    int old_S = sum;
    if (sum != M && i <= n) {
        for(int j = -1; j <= 1; j++) {
            x[i] = j;
            if (j == 1) sum = sum + m[i];
            if (j == -1) sum = sum - m[i];
            TRY(i + 1);
            sum = old_S;
            x[i] = 0;
        }
    }
}
int main() {
    cin >> n >> M;
    for (int i = 1; i <= n; ++i){
        cin >> m[i];
    }
    TRY (1);
    return 0;
}
*/
struct state{
    int i, j, old_S;
    state(int _i = 0, int _j = 0): i(_i), j(_j) {}
};

int main() {
    int n, M;
    cin >> n >> M;
    int m[n+1];
    for (int i = 1; i <= n; ++i) cin >> m[i];
    int x[n+1];
    stack<state> s;
    //# sum of selected weights
    int sum = 0;
    s.push(state(1, -1));
    while (!s.empty()){
        state &top = s.top();
        if (sum == M){
            for (int i = 1; i <= n; ++i){
                if (x[i] == -1) cout << '-' << m[i];
                if (x[i] == 1) cout << '+' << m[i];
            }
            cout << " = " << M <<endl;
            exit(0);
            s.pop();
        }

        // #backtrack
        if (top.j > -1)
            sum = top.old_S;

        // #every subtree are visited
        if (top.j > 1) {
            x[top.i] = 0;
            s.pop();
            continue;
        }

        if (sum != M && top.i <= n) {
            x[top.i] = top.j;
            top.old_S = sum;
            if(top.j == 1) sum += m[top.i];
            if(top.j == -1) sum -= m[top.i];
            s.push(state(top.i + 1, -1));
        }
        ++top.j;
        //# Khử đệ quy
        /*****************
        # YOUR CODE HERE #
        *****************/
    }
    return 0;
}
