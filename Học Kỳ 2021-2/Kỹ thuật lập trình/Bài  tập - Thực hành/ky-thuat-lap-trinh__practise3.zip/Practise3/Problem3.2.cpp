#include <bits/stdc++.h>

int n, X[100], Y[100], mark[100][100];
const int hx[] = {1, 1, 2, 2, -1, -1, -2, -2};
const int hy[] = {2, -2, 1, -1, 2, -2, 1, -1};

process(int i, int x, int y){
    if (i > n * n){
        for (int j = 1; j < i; ++j)
            printf("(%d %d) \n", X[j], Y[j]);
        exit(0);
    }
    /*****************
    # YOUR CODE HERE #
    *****************/
    for (int t = 0; t < 8; t++) {
        int x1 = x + hx[t];
        int y1 = y + hy[t];
            if (x1 < 1 || x1 > n) {
                continue;
            }
            if (y1 < 1 || y1 > n) {
                continue;
            }
        if(!mark[x1][y1]){
            X[i] = x1;
            Y[i] = y1;
            mark[x1][y1] = 1;
            process(++i, x1, y1);
            mark[x1][y1] = 0;
        }
    }
}

int main()
{
    n = 3;
    mark[1][1] = 1;
    X[1] = Y[1] = 1;
    process(2, 1, 1);
    return 0;
}
