#include <bits/stdc++.h>
using namespace std;

int main () {
    cout << log2(2);
    return 0;
}
