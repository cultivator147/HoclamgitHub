#include <iostream>
using namespace std;
struct Node {
    int data;
    Node* next;

    Node(int data) {
        this->data = data;
        next = NULL;
    }
};

// push a new element to the beginning of the list
Node* prepend(Node* head, int data) {
    Node *newNode = new Node(data);
    if (head == NULL) {
        head = newNode;
        return head;
    }
    newNode->next = head;
    return newNode;
    /*****************
    # YOUR CODE HERE #
    *****************/
}

void print(Node* head) {
    if (head == NULL) {
        cout<<endl;
        return;
        }
    cout<<head->data<<" ";
    head = head->next;
    print(head);

    /*****************
    # YOUR CODE HERE #
    *****************/
}

// return the new head of the reversed list
Node* reverse(Node* head) {
    if (head == NULL) return NULL;
    Node *p = head;
    Node *h = head;
    Node *q;
    p = p-> next;
    while(p != NULL) {
        q = p;
        p = p->next;
        q->next = head;
        head = q;
    }
    h->next = NULL;
    return head;
    /*****************
    # YOUR CODE HERE #
    *****************/
}

/*Node* reverse(Node* head) {
    if (head == NULL) return NULL;
    Node *prev = NULL;
    Node *next = NULL;
    while(head != NULL) {
        next = head->next;
        head->next = prev;
        prev = head;
        head = next;
    }
    return prev;
    /*****************
    # YOUR CODE HERE #
    *****************/
//}

int main() {
    Node* head = NULL;
    for (int i = 0; i < 10; ++i) head = prepend(head, i);

    cout << "Original list: ";
    print(head);

    head = reverse(head);

    cout << "Reversed list: ";
    print(head);

    return 0;
}
