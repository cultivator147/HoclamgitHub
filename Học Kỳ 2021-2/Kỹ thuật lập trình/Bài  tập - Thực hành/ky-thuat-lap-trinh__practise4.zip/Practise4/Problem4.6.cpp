#include <vector>
#include <list>
#include <iostream>
#include <queue>
using namespace std;

int n;

void bfs(vector< list<int> > adj) {
    queue<int> q;
    bool visit[n+1];
    q.push(1);
    visit[1] = true;
    while(!q.empty()){
        int s = q.front();
        cout << s <<" ";
        int index = s;
        q.pop();

        list<int> :: iterator it;
        for(it = adj[index].begin() ; it != adj[index].end(); it++){
            if(!visit[*it]) {
                q.push(*it);
                visit [*it] = 1;
            }
        }
        if(q.empty()){
            for (int i = 1; i < n; i++){
                if(!visit[i]){
                    q.push(i);
                    index = i;
                    visit[i] = true;
                    break;
                }
            }
        }
    }
    /*****************
    # YOUR CODE HERE #
    *****************/
}

int main() {
    n = 7;
    vector< list<int> > adj;
    adj.resize(n + 1);
    adj[1].push_back(2);
    adj[2].push_back(4);
    adj[1].push_back(3);
    adj[3].push_back(4);
    adj[3].push_back(5);
    adj[5].push_back(2);
    adj[2].push_back(7);
    adj[6].push_back(7);
    bfs(adj);

    return 0;
}
