#include <vector>
#include <list>
#include <iostream>
#include <stack>
using namespace std;

int n;

void dfs(vector< list<int> > adj) {
    stack<int> st;
    bool visit[20] = {0};
    int tmp = 0;
    st.push(1);
    visit[1] = true;
    cout<< 1 << " ";
    int index = 1;
    int old_vertex = 1;

    list<int> :: iterator it ;

    if(adj[index].size() == 0 && visit[index] == 0){
        cout<<index<<" ";
        visit[index] = 1;
    }

  	while(!st.empty()){
  		it = adj[index].begin();
  		for(int j = 0; j < adj[index].size(); j++){
  			advance(it,j);
  			if(!visit[index]) {
                st.push(index);
                visit[index] = true;
                cout<< index << " ";
            }
  			if(visit[*it] == 0){
  				int temp = *it;
  				st.push(*it);
  				cout<< *it << " ";
  				visit[*it] = true;
  				index = temp;
  				j = -1;
  				it = adj[index].begin();
            }
            it = adj[index].begin();
        }
        st.pop();
        if(!st.empty()) index = st.top();
        else {
            for(int i = 1;i <= n;i++){
                if(!visit[i]) {
                    tmp = i;
                    st.push(tmp);
                    index = tmp;
                    break;
                }
            }
        }
	}
    /*****************
    # YOUR CODE HERE #
    *****************/
}

int main() {
    n = 7;
    vector< list<int> > adj;
    adj.resize(n + 1);
    adj[1].push_back(2);
    adj[2].push_back(4);
    adj[1].push_back(3);
    adj[3].push_back(4);
    adj[3].push_back(5);
    adj[5].push_back(2);
    adj[2].push_back(7);
    adj[6].push_back(7);
    dfs(adj);

    return 0;
}
