#include<iostream>
#include <cmath>
#include <iomanip>
#include <utility>
using namespace std;
using Point = pair<double, double>;

/*double area(Point a, Point b, Point c) {
    double x = sqrt(pow(a.first - b.first,2) + pow(a.second - b.second,2));
    double y = sqrt(pow(b.first - c.first,2) + pow(b.second - c.second,2));
    double z = sqrt(pow(c.first - a.first,2) + pow(c.second - a.second,2));
    double p = (x + y + z)*0.5;
    return sqrt(p*(p - x)*(p - y)*(p - z));
    /*****************
    # YOUR CODE HERE #
    *****************/
//}

double area(Point a, Point b, Point c) {
    double x = (b.first - a.first)*(c.second - a.second);
    double y = (c.first - a.first)*(b.second - a.second);
    return 0.5*fabs(x-y);
    /*****************
    # YOUR CODE HERE #
    *****************/
}

int main() {
    cout << setprecision(2) << fixed;
    cout << area({1, 2}, {2.5, 10}, {15, -5.25}) << endl;
    return 0;
}
