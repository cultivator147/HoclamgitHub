double* maximum(double* a, int size){
    double *max;
    max = a;
    if (a==NULL) return NULL;

	// neu gia tri cua con tro ma  max dang tro toi < gia tri cua phan tu ke tiep thi
	// gan gia tri phan tu ke tiep cho max.
   for(int i = 0; i < size;i++) if (*max < *(max+i)) *max =*(max + i);
    
    return max;
}
