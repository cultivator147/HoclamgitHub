#include<stdio.h>
#include<stdlib.h>
int main(){
	int x, y, z;
	int *ptr;
	
	printf("Trinh Minh Hieu - 20204554 - 715026\n");
	
	printf("Enter three integers: ");
	scanf("%d %d %d", &x, &y, &z);
	printf("\nThe three integers are:\n");
	ptr = &x;
	printf("x = %d\n", *ptr);
	
	ptr = &y;         // con tro tro toi dia chi cua y;
	printf("y = %d\n", *ptr);    // in ra gia tri cua y
	
	ptr = &z;        // con tro tro toi z;
	printf("z = %d\n", *ptr);     // in ra gia tri cua z
	
	return 0;
}
