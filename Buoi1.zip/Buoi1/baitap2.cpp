#include <stdio.h>
int main(){
	printf("Trinh Minh Hieu - 20204554 - 715026\n");
    int a[7]= {13, -355, 235, 47, 67, 943, 1222}; 
    printf("address of first five elements in memory.\n");
    for (int i=0; i<5;i++)  printf("\ta[%d] ",i);
    printf("\n");
    
    for (int i = 0; i < 5;i++) printf("\t%p", &a[i]); //in ra dia chi 5 phan tu dau tien trong mang
    printf("\n");   // in cach dong
           
    return 0;
}
