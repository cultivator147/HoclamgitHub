#include <stdio.h>
int main()
{
	printf("Trinh Minh Hieu - 20204554 - 715026\n");
    int x, y, z;
    int *ptr;
    scanf("%d %d %d", &x, &y, &z);
    printf("Here are the values of x, y, and z:\n");
    printf("%d %d %d\n", x, y, z);

 
    ptr = &x;			// con tro tro den bien x
    *ptr = *ptr + 100;   //gia tri cua x tang len 100
    
    ptr = &y;   // con tro tro den bien y
    *ptr = *ptr + 100;		// tang gia tri cua y len 100
    	
    ptr = &z;     //con tro tro den bien z
    *ptr = *ptr + 100;			//tang gia tri cua z len 100
  
    
    printf("Once again, here are the values of x, y, and z:\n");
    printf("%d %d %d\n", x, y, z);
    return 0;
}    
